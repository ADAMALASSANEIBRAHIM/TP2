#-----------------------------------------------

#  IMPORTATION DE LA BASE    

#-----------------------------------------------

library(readxl)
library(dplyr)
library(questionr)
library(forcats)

base_tp2 <- read_excel("data/Base TP2.xlsx")

base_tp2 %>% sjPlot::view_df()   #  Pour voir clair

#-----------------------------------------------

#  RECODAGE ET LABELLISATION    

#-----------------------------------------------

#------   RECODAGE

# Pour voir le nom de toutes les variables

colnames(base_tp2)

str(base_tp2)

# ou

names(base_tp2)

# dput nous permet d'avoir les noms sous la forme de vecteur
# A partir de là, le recodage devient facile.

nouv_nom <- dput(names(base_tp2)) 

nouv_nom <- c("region", "departement", "sexe", "age", "sit_mat", "si_chef_men", 
              "ethnie", "occupation", "formation", "niveau_alphabs", "types_varietes", 
              "types_varietes_1", "types_varietes_2", "criteres_var", "rendem_elv", 
              "taille_graine", "resistance", "tol_sech", "tol_inond", 
              "fbl_ch_W", "fbl_input", "fcl_transform", "hte_teneur_huile", 
              "ht_rendement_after", "demande_market", "bon_gout", "belle_couleur", 
              "ht_rend_fourage", "qlt_fourage", "autre")

# On peut facilement affecter nouv_nom à names

names(base_tp2) <- nouv_nom

base_tp2 <- base_tp2 %>% mutate(across(-c(age), factor))


#-----------------------------------------------------------

#Recodage avec ifelse (variable dichotomique)

#---------------------------------------------------------------



rec_dicho <- function(nom_base, variable, test, true, false){
  
  attach(nom_base)
  
  trans <- ifelse(variable == test, true, false)
  
  nom <- trans
  
}
  
  

base_tp2$sexe <- ifelse(base_tp2$sexe == 1,yes = "Homme", no = "Femme")

base_tp2$types_varietes <- ifelse(base_tp2$types_varietes == 1,
                                  "Traditionnelles", "Améliorées")

#---------------------------------------------------------------------

#Recodage de la situatuion maritale

#---------------------------------------------------------irec------------

# Nous allons utiliser la fonction 
#fct_recode du package forcats

base_tp2$sit_mat <- base_tp2$sit_mat %>%
  forcats::fct_recode("Marié" = "1",
                      "Veuf(ve)" = "3",
                        "Divorcé" = "4",
                      "Séparé" = "5",
                      "Célibataire" = "6")


# Pour la variable ethnie

base_tp2$ethnie <- base_tp2$ethnie %>%
  fct_recode(
    "Wolof" = "1",
    "Pulaar/Toucouleur" = "2",
    "Sérère" = "3",
    "Mandika/ Bambara" = "4",
    "Diola" = "6",
    "Balante" = "10",
    "Autre" = "77"
  )

# Statut du chef de ménage

irec()
## Recodage de base_tp2$si_chef_men
base_tp2$si_chef_men <- base_tp2$si_chef_men %>%
  fct_recode(
    "femme du chef de ménage" = "1",
    "chef de ménage" = "2",
    "fils-fille du chef de ménage" = "3"
  )

#  Recodage de la variable Occupation

irec()
## Recodage de base_tp2$formation
base_tp2$formation <- base_tp2$formation %>%
  fct_recode(
    "Non scolarisé" = "1",
    "Elémentaire" = "2",
    "Moyen" = "3",
    "Secondaire" = "4",
    "Licence" = "5",
    "Ne sait pas" = "99"
  )
